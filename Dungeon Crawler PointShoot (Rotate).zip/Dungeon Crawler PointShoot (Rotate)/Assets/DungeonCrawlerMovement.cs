using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonCrawlerMovement : MonoBehaviour
{
    public float speed;
    public float shootTime;
    private float timer;
    public GameObject projectile;
    private Vector2 lastV = Vector2.down;
    // Update is called once per frame
    void Update()
    {
        Vector2 v = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
       //var anim = GetComponent<Animator>();
       //anim.SetFloat("Horizontal", v.x);
       //anim.SetFloat("Vertical", v.y);
        if(v.magnitude > 0)
        {
            lastV = v.normalized;
        }
        v.Normalize();
        GetComponent<Rigidbody2D>().velocity = v * speed;
        
        if(Input.GetMouseButtonDown(0) && timer <= 0)
        {
            timer = shootTime;
            var g = Instantiate(projectile, transform.position, Quaternion.identity);
            g.GetComponent<Rigidbody2D>().velocity = lastV * speed * 2;
        }
        else if(timer > 0)
        {
            timer -= Time.deltaTime;
        }
    }
}
